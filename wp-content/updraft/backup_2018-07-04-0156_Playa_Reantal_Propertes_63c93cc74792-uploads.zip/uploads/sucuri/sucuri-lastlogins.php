<?php exit(0); ?>
{"user_id":1,"user_login":"PlayaRentalProperties","user_remoteaddr":"69.7.250.80","user_hostname":"ka-wrl-kgn-ip780.kos.net","user_lastlogin":"2018-07-02 14:51:05"}
{"user_id":2,"user_login":"JoeRahill","user_remoteaddr":"69.7.250.80","user_hostname":"ka-wrl-kgn-ip780.kos.net","user_lastlogin":"2018-07-02 15:58:46"}
{"user_id":2,"user_login":"JoeRahill","user_remoteaddr":"69.7.250.80","user_hostname":"ka-wrl-kgn-ip780.kos.net","user_lastlogin":"2018-07-02 16:13:59"}
{"user_id":2,"user_login":"JoeRahill","user_remoteaddr":"69.7.250.80","user_hostname":"ka-wrl-kgn-ip780.kos.net","user_lastlogin":"2018-07-02 16:16:34"}
{"user_id":2,"user_login":"JoeRahill","user_remoteaddr":"189.221.33.222","user_hostname":"189.221.33.222.cable.dyn.cableonline.com.mx","user_lastlogin":"2018-07-03 19:47:46"}
{"user_id":1,"user_login":"PlayaRentalProperties","user_remoteaddr":"69.7.250.80","user_hostname":"ka-wrl-kgn-ip780.kos.net","user_lastlogin":"2018-07-03 23:38:49"}
{"user_id":1,"user_login":"PlayaRentalProperties","user_remoteaddr":"189.221.33.222","user_hostname":"189.221.33.222.cable.dyn.cableonline.com.mx","user_lastlogin":"2018-07-03 23:40:10"}
