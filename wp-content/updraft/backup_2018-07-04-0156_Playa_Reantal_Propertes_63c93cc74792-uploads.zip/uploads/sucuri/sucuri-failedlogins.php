<?php exit(0); ?>
{"user_login":"PlayaRentalProperties","attempt_time":1530661093,"remote_addr":"189.221.33.222","user_agent":"Mozilla\/5.0 (X11; Linux x86_64) AppleWebKit\/537.36 (KHTML, like Gecko) Ubuntu Chromium\/66.0.3359.181 Chrome\/66.0.3359.181 Safari\/537.36"}
{"user_login":"PlayaRentalProperties","attempt_time":1530661093,"remote_addr":"189.221.33.222","user_agent":"Mozilla\/5.0 (X11; Linux x86_64) AppleWebKit\/537.36 (KHTML, like Gecko) Ubuntu Chromium\/66.0.3359.181 Chrome\/66.0.3359.181 Safari\/537.36"}
